## Introduce project
 It's my first project.
 Motivate to make this project is that our school members are used to confuse our school structure. (Not only new member, but also enrolled student)
 So, I want to make some program that they can find class ASAP. 

## Start Project
 Ⅰ. No modify
  0. First, set up essential modlue.
  1. Execute "school_map > src > main.html".

 Ⅱ. modify 
  0. Change blueprint in "school_map > src > planner" channel.
  1. Adjust picture route "url" in "school_map > src > main_search.js".
  2. Adjust text arrangement on picture. 
 